+---------------------------------------------------------------------+
|---------------------------------------------------------------------|
||                                                                   ||
||  ███╗   ███╗ █████╗ ███████╗███████╗███████╗     ██████╗ ███████╗ ||
||  ████╗ ████║██╔══██╗╚══███╔╝██╔════╝██╔════╝    ██╔═══██╗██╔════╝ ||
||  ██╔████╔██║███████║  ███╔╝ █████╗  ███████╗    ██║   ██║█████╗   ||
||  ██║╚██╔╝██║██╔══██║ ███╔╝  ██╔══╝  ╚════██║    ██║   ██║██╔══╝   ||
||  ██║ ╚═╝ ██║██║  ██║███████╗███████╗███████║    ╚██████╔╝██║      ||
||  ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝     ╚═════╝ ╚═╝      ||
||                                                                   ||
||        ████████╗██╗    ██╗██╗███████╗████████╗██╗   ██╗           ||
||        ╚══██╔══╝██║    ██║██║██╔════╝╚══██╔══╝╚██╗ ██╔╝           ||
||           ██║   ██║ █╗ ██║██║███████╗   ██║    ╚████╔╝            ||
||           ██║   ██║███╗██║██║╚════██║   ██║     ╚██╔╝             ||
||           ██║   ╚███╔███╔╝██║███████║   ██║      ██║              ||
||           ╚═╝    ╚══╝╚══╝ ╚═╝╚══════╝   ╚═╝      ╚═╝              ||
||                                                                   ||
|| ██████╗  █████╗ ███████╗███████╗ █████╗  ██████╗ ███████╗███████╗ ||
|| ██╔══██╗██╔══██╗██╔════╝██╔════╝██╔══██╗██╔════╝ ██╔════╝██╔════╝ ||
|| ██████╔╝███████║███████╗███████╗███████║██║  ███╗█████╗  ███████╗ ||
|| ██╔═══╝ ██╔══██║╚════██║╚════██║██╔══██║██║   ██║██╔══╝  ╚════██║ ||
|| ██║     ██║  ██║███████║███████║██║  ██║╚██████╔╝███████╗███████║ ||
|| ╚═╝     ╚═╝  ╚═╝╚══════╝╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚══════╝ ||
||                                                                   ||
|---------------------------------------------------------------------|
|---------------------------------------------------------------------|
||      _  _ _    _     _____ _                                      ||
||     | \| (_)__| |__ |_   _| |_  ___ _ __  _ __ ______ _ _         ||
||     | .` | / _| / /   | | | ' \/ _ \ '  \| '_ (_-< _ \ ' \        ||
||     |_|\_|_\__|_\_\   |_| |_||_\___/_|_|_| .__/__|___/_||_|       ||
||                                          |_|                      ||
||      __  __      _   _     ___     _                 _ _          ||
||     |  \/  |__ _| |_| |_  / __| __| |_  __ _ _ _  __| (_)_ _      ||
||     | |\/| / _` |  _|  _| \__ \/ _| ' \/ _` | ' \|_ / | | ' \     ||
||     |_|  |_\__,_|\__|\__| |___/\__|_||_\__,_|_||_/__|_|_|_||_|    ||
||                                                                   ||
|---------------------------------------------------------------------|
|---------------------------------------------------------------------|
||                                                                   ||
||  ----------------------   MENU CONTROLS   ----------------------  ||
||                                                                   ||
||  CLICK -- SELECT BUTTON                                           ||
||                                                                   ||
||  LEFT / RIGHT -- INCREASE/DECREASE CUSTOM MAZE WIDTH              ||
||                                                                   ||
||  UP / DOWN -- INCREASE/DECREASE CUSTOM MAZE HEIGHT                ||
||                                                                   ||
||  + / - -- INCREASE/DECREASE CUSTOM MAZE CELL SIZE                 ||
||                                                                   ||
|---------------------------------------------------------------------|
||                                                                   ||
||  ----------------------   MAZE CONTROLS   ----------------------  ||
||                                                                   ||
||  R -- RESETS THE CURRENT MAZE                                     ||
||                                                                   ||
||  1 -- CREATES A NEW RANDOM MAZE                                   ||
||                                                                   ||
||  2 -- CREATES A NEW HORIZONTALLY BIASED MAZE                      ||
||                                                                   ||
||  3 -- CREATES A NEW VERTICALLY BIASED MAZE                        ||
||                                                                   ||
||  D -- DEPTH FIRST SEARCH                                          ||
||                                                                   ||
||  B -- BREADTH FIRST SEARCH                                        ||
||                                                                   ||
||  P -- TURNS ON PLAYER BASED SEARCH                                ||
||                                                                   ||
||  LEFT / RIGHT / UP / DOWN -- MOVES PLAYER WHEN IT IS ENABLED      ||
||                                                                   ||
||  L -- YOU CAN "LERN" FOR YOURSELF  (AN EASTER EGG FOR OUR PROF)   ||
||                                                                   ||
||  S -- TOGGLES VIEW OF MINIMUM SPANNING TREE                       ||
||                                                                   ||
||  H -- TOGGLES HEATMAP OF MAZE BASED ON A BFS                      ||
||                                                                   ||
||  A -- TOGGLES ANIMATION FOR CREATION OF NEW MAZES                 ||
||                                                                   ||
||  V -- TOGGLES VIEW OF VISITED PATHES                              ||
||                                                                   ||
|---------------------------------------------------------------------|
||                                                                   ||
||  ---------------------   GETTING STARTED   ---------------------  ||
||                                                                   ||
|| To start, launch the runnable JAR file. If launching from source, ||
|| use MazeWorldLauncher for the program arguments when using the    ||
|| Tester library. To see test results, use Examples for the program ||
|| arguments.                                                        ||
||                                                                   ||
|| To launch a maze, click one of the buttons for a small, big, or   ||
|| custom sized maze. Use the menu controls above to adjust the      ||
|| parameters of the custom maze, and click the ? to get back to     ||
|| this file. Click start when ready.                                ||
||                                                                   ||
|| Once a maze has launched, you can start a breadth or depth first  ||
|| search using the keys shown above. You can also turn on the       ||
|| player and try to solve it on your own. Additional controls and   ||
|| toggles for other maze features are shown above.                  ||
||                                                                   ||
|---------------------------------------------------------------------|
+---------------------------------------------------------------------+
